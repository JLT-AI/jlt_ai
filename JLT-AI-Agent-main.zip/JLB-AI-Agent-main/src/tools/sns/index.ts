export * from "./get_all_registered_all_domains";
export * from "./get_main_all_domains_domain";
export * from "./get_primary_domain";
export * from "./register_domain";
export * from "./resolve_sol_domain";
